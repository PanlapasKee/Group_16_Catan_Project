"""
board.py
========
Defines the Board and Tile classes.

The board is a standard 19-hex Catan layout arranged in a 3-4-5-4-3
row pattern.  Each tile has:
  - a terrain type
  - a number token (2-12, not 7; desert has none)
  - a set of vertex IDs (corners) and edge IDs (sides)

Vertices (corners) and edges are shared between adjacent tiles and
are used to track settlement and road placement.

Data model
----------
  Tile           – one hexagonal terrain tile
  Board          – full 19-tile board + vertex/edge graph
"""

from __future__ import annotations
import random
from typing import Dict, List, Optional, Tuple, Set

from utils.constants import (
    BOARD_ROWS, TILE_DISTRIBUTION, NUMBER_TOKENS,
    TILE_RESOURCE_MAP, TILE_COLORS,
)
from utils.helpers import hex_to_pixel, hex_corners


# ---------------------------------------------------------------------------
# Tile
# ---------------------------------------------------------------------------

class Tile:
    """
    One hexagonal land tile.

    Attributes
    ----------
    tile_id   : int          Unique 0-based index.
    tile_type : str          e.g. "forest", "desert".
    resource  : str | None   Resource produced, or None for desert.
    number    : int | None   Dice number token, or None for desert.
    col, row  : int          Grid coordinates.
    vertices  : list[int]    Clockwise vertex IDs starting top-left.
    pixel_x   : float        Pixel centre x (set by Board).
    pixel_y   : float        Pixel centre y (set by Board).
    has_robber: bool         True when the robber is here.
    """

    def __init__(
        self,
        tile_id:   int,
        tile_type: str,
        resource:  Optional[str],
        number:    Optional[int],
        col:       int,
        row:       int,
    ) -> None:
        self.tile_id:    int           = tile_id
        self.tile_type:  str           = tile_type
        self.resource:   Optional[str] = resource
        self.number:     Optional[int] = number
        self.col:        int           = col
        self.row:        int           = row
        self.vertices:   List[int]     = []   # populated by Board
        self.edges:      List[Tuple]   = []   # populated by Board
        self.pixel_x:    float         = 0.0
        self.pixel_y:    float         = 0.0
        self.has_robber: bool          = (tile_type == "desert")

    # ------------------------------------------------------------------

    @property
    def color(self) -> str:
        return TILE_COLORS.get(self.tile_type, "#cccccc")

    def __repr__(self) -> str:
        return (f"Tile(id={self.tile_id}, type={self.tile_type!r}, "
                f"number={self.number}, row={self.row}, col={self.col})")


# ---------------------------------------------------------------------------
# Board
# ---------------------------------------------------------------------------

class Board:
    """
    The full Catan game board.

    Responsibilities
    ----------------
    - Create and store all 19 Tile objects.
    - Assign pixel coordinates to each tile centre.
    - Build a vertex graph (54 vertices) and edge graph.
    - Map dice numbers → list of tiles that produce on that roll.
    - Track which player owns each vertex / edge.

    Public attributes
    -----------------
    tiles          : list[Tile]
    vertices       : dict[int, dict]   vertex_id → {owner, structure}
    edges          : dict[tuple, dict] (v1, v2) → {owner}
    number_to_tiles: dict[int, list[Tile]]
    """

    # Size parameters forwarded to helpers
    HEX_SIZE   = 60
    ORIGIN_X   = 60
    ORIGIN_Y   = 50

    def __init__(self) -> None:
        self.tiles:           List[Tile]            = []
        self.vertices:        Dict[int, dict]        = {}   # vertex_id → info
        self.edges:           Dict[Tuple, dict]      = {}   # (v1,v2) → info
        self.number_to_tiles: Dict[int, List[Tile]]  = {}

        self._build_board()

    # ------------------------------------------------------------------
    # Board construction
    # ------------------------------------------------------------------

    def _build_board(self) -> None:
        """Construct all tiles, assign numbers, build vertex graph."""
        tile_types = TILE_DISTRIBUTION[:]
        random.shuffle(tile_types)

        numbers = NUMBER_TOKENS[:]
        random.shuffle(numbers)

        tile_id = 0
        for row_idx, n_cols in enumerate(BOARD_ROWS):
            for col_idx in range(n_cols):
                ttype    = tile_types[tile_id]
                resource = TILE_RESOURCE_MAP[ttype]

                if ttype == "desert":
                    number = None
                else:
                    number = numbers.pop() if numbers else None

                tile = Tile(tile_id, ttype, resource, number, col_idx, row_idx)

                # Pixel centre
                px, py = hex_to_pixel(
                    col_idx, row_idx,
                    self.HEX_SIZE, self.ORIGIN_X, self.ORIGIN_Y
                )
                tile.pixel_x = px
                tile.pixel_y = py

                self.tiles.append(tile)
                tile_id += 1

        # Build vertex and edge structures
        self._build_vertex_graph()
        self._index_numbers()

    def _build_vertex_graph(self) -> None:
        """
        Assign vertex IDs to each tile and populate self.vertices / self.edges.

        Strategy: compute the 6 corner pixel positions for each tile, round
        them to integers and use them as a position key to share vertices
        between adjacent tiles.
        """
        pos_to_id: Dict[Tuple[int, int], int] = {}
        next_vid = 0

        for tile in self.tiles:
            corners = hex_corners(tile.pixel_x, tile.pixel_y, self.HEX_SIZE)
            vertex_ids = []
            for cx, cy in corners:
                key = (round(cx), round(cy))
                if key not in pos_to_id:
                    pos_to_id[key] = next_vid
                    self.vertices[next_vid] = {
                        "owner":     None,   # player or None
                        "structure": None,   # "settlement" | "city" | None
                        "pixel":     key,
                    }
                    next_vid += 1
                vertex_ids.append(pos_to_id[key])
            tile.vertices = vertex_ids

            # Register edges (pairs of adjacent vertices)
            for i in range(6):
                v1 = vertex_ids[i]
                v2 = vertex_ids[(i + 1) % 6]
                edge = (min(v1, v2), max(v1, v2))
                if edge not in self.edges:
                    self.edges[edge] = {"owner": None}
                tile.edges.append(edge)

    def _index_numbers(self) -> None:
        """Build the number → [Tile, …] lookup used for resource distribution."""
        for tile in self.tiles:
            if tile.number is not None:
                self.number_to_tiles.setdefault(tile.number, []).append(tile)

    # ------------------------------------------------------------------
    # Game logic helpers
    # ------------------------------------------------------------------

    def get_tiles_for_roll(self, roll: int) -> List[Tile]:
        """Return all tiles whose number matches the dice roll."""
        return self.number_to_tiles.get(roll, [])

    def is_vertex_free(self, vertex_id: int) -> bool:
        """True if no structure occupies this vertex."""
        return self.vertices[vertex_id]["owner"] is None

    def is_edge_free(self, edge: Tuple[int, int]) -> bool:
        """True if no road occupies this edge."""
        edge = (min(edge), max(edge))
        return self.edges.get(edge, {}).get("owner") is None

    def place_settlement(self, vertex_id: int, player) -> None:
        """
        Mark vertex as occupied by a settlement.
        :raises ValueError: if vertex is already occupied.
        """
        if not self.is_vertex_free(vertex_id):
            raise ValueError(f"Vertex {vertex_id} is already occupied.")
        self.vertices[vertex_id]["owner"]     = player
        self.vertices[vertex_id]["structure"] = "settlement"

    def upgrade_to_city(self, vertex_id: int, player) -> None:
        """
        Upgrade a settlement to a city.
        :raises ValueError: if vertex doesn't belong to this player.
        """
        v = self.vertices[vertex_id]
        if v["owner"] is not player or v["structure"] != "settlement":
            raise ValueError(
                f"Vertex {vertex_id} does not have {player.name}'s settlement."
            )
        v["structure"] = "city"

    def place_road(self, edge: Tuple[int, int], player) -> None:
        """
        Mark an edge as occupied by a road.
        :raises ValueError: if edge is already occupied.
        """
        edge = (min(edge), max(edge))
        if not self.is_edge_free(edge):
            raise ValueError(f"Edge {edge} already has a road.")
        self.edges[edge]["owner"] = player

    def get_vertices_for_player(self, player) -> List[int]:
        """Return all vertex IDs owned by player."""
        return [vid for vid, v in self.vertices.items() if v["owner"] is player]

    def vertices_adjacent_to_tile(self, tile: Tile) -> List[int]:
        """Return the 6 vertex IDs of this tile."""
        return tile.vertices

    def move_robber(self, new_tile_id: int) -> None:
        """Move the robber from its current tile to new_tile_id."""
        for tile in self.tiles:
            tile.has_robber = (tile.tile_id == new_tile_id)

    def robber_tile(self) -> Optional[Tile]:
        """Return the tile currently holding the robber."""
        for tile in self.tiles:
            if tile.has_robber:
                return tile
        return None

    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return f"Board(tiles={len(self.tiles)}, vertices={len(self.vertices)}, edges={len(self.edges)})"
