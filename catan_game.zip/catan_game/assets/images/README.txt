# Assets directory
# Place custom PNG images here (e.g. hex tile textures).
# Filename convention: wood.png, brick.png, sheep.png, wheat.png, ore.png, desert.png
# The game works without any files in this directory.
